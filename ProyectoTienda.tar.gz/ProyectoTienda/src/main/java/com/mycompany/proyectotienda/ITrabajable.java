package com.mycompany.proyectotienda;

public interface ITrabajable {
    
    public String ejecutarTrabajo(); 
    
}
