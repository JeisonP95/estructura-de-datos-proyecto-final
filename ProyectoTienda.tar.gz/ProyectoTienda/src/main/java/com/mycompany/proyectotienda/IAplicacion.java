package com.mycompany.proyectotienda;

public interface IAplicacion {

    public String AbrirApp();

    public String ActualizarApp();

    public String EliminarApp();

}
